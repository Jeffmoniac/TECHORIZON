from django.contrib import admin
from .models import Registrant

admin.site.register(Registrant)